<?php

require './views/footer.view.php';

?>